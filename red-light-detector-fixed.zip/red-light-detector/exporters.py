"""Экспорт результатов анализа в Excel, PDF и JSON."""

from __future__ import annotations

import json
from html import escape
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


STATUS_LABELS = {
    "queued": "В очереди",
    "processing": "Выполняется",
    "completed": "Завершён",
    "failed": "Ошибка",
}


def export_excel(path: str | Path, analysis: dict, violations: list[dict]) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    workbook = Workbook()
    summary = workbook.active
    summary.title = "Сводка"
    summary_rows = [
        ("Идентификатор анализа", analysis["id"]),
        ("Исходный файл", analysis["original_filename"]),
        ("Дата создания", analysis["created_at"]),
        ("Статус", STATUS_LABELS.get(analysis["status"], analysis["status"])),
        ("Кадров обработано", analysis["total_frames"]),
        ("Длительность, с", round(analysis["duration_sec"], 2)),
        ("Частота кадров", round(analysis["fps"], 2)),
        ("Нарушений", analysis["violations_count"]),
        ("Y-координата стоп-линии", analysis["stop_line_y"]),
        (
            "Область светофора (x, y, w, h)",
            f"{analysis['traffic_light_x']}, {analysis['traffic_light_y']}, "
            f"{analysis['traffic_light_w']}, {analysis['traffic_light_h']}",
        ),
    ]
    for row in summary_rows:
        summary.append(row)
    summary.column_dimensions["A"].width = 34
    summary.column_dimensions["B"].width = 48
    for cell in summary["A"]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="17233B")

    events = workbook.create_sheet("Нарушения")
    headers = [
        "№",
        "Кадр",
        "Время, с",
        "ID транспорта",
        "Тип",
        "Уверенность",
        "Доля красного",
        "Координаты рамки",
        "Файл доказательства",
    ]
    events.append(headers)
    for index, item in enumerate(violations, start=1):
        events.append(
            [
                index,
                item["frame_number"],
                round(item["time_sec"], 3),
                item["track_id"],
                item["vehicle_class"],
                round(item["confidence"], 4),
                round(item["red_ratio"], 4),
                f"({item['x1']}, {item['y1']}) - ({item['x2']}, {item['y2']})",
                item["evidence_filename"],
            ]
        )
    for cell in events[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="D44242")
        cell.alignment = Alignment(horizontal="center")
    events.freeze_panes = "A2"
    events.auto_filter.ref = events.dimensions
    widths = [7, 12, 13, 16, 18, 16, 17, 30, 34]
    for index, width in enumerate(widths, start=1):
        events.column_dimensions[get_column_letter(index)].width = width

    workbook.save(output)
    return output


def _register_pdf_fonts() -> tuple[str, str]:
    regular = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
    bold = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
    if regular.exists() and bold.exists():
        if "DejaVu" not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont("DejaVu", str(regular)))
            pdfmetrics.registerFont(TTFont("DejaVu-Bold", str(bold)))
        return "DejaVu", "DejaVu-Bold"
    return "Helvetica", "Helvetica-Bold"


def export_pdf(
    path: str | Path,
    analysis: dict,
    violations: list[dict],
    evidence_dir: str | Path,
) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    regular_font, bold_font = _register_pdf_fonts()
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "RussianTitle",
        parent=styles["Title"],
        fontName=bold_font,
        fontSize=20,
        leading=25,
        textColor=colors.HexColor("#17233B"),
        alignment=TA_CENTER,
        spaceAfter=10 * mm,
    )
    heading_style = ParagraphStyle(
        "RussianHeading",
        parent=styles["Heading2"],
        fontName=bold_font,
        fontSize=13,
        leading=17,
        textColor=colors.HexColor("#17233B"),
        spaceBefore=5 * mm,
        spaceAfter=3 * mm,
    )
    body_style = ParagraphStyle(
        "RussianBody",
        parent=styles["BodyText"],
        fontName=regular_font,
        fontSize=9,
        leading=13,
    )

    document = SimpleDocTemplate(
        str(output),
        pagesize=A4,
        rightMargin=16 * mm,
        leftMargin=16 * mm,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
        title="Отчёт о детекции проезда на красный сигнал",
        author="Red Light Detector",
    )
    story = [
        Paragraph("Отчёт о детекции проезда на красный сигнал", title_style),
        Paragraph("Сводная информация", heading_style),
    ]
    summary_data = [
        ["Параметр", "Значение"],
        ["Файл", escape(str(analysis["original_filename"]))],
        ["Дата анализа", escape(str(analysis["created_at"]))],
        ["Кадров", str(analysis["total_frames"])],
        ["Длительность", f"{analysis['duration_sec']:.2f} с"],
        ["Частота кадров", f"{analysis['fps']:.2f} FPS"],
        ["Нарушений", str(analysis["violations_count"])],
        ["Стоп-линия", f"Y = {analysis['stop_line_y']}"],
    ]
    summary_table = Table(summary_data, colWidths=[62 * mm, 100 * mm])
    summary_table.setStyle(
        TableStyle(
            [
                ("FONTNAME", (0, 0), (-1, -1), regular_font),
                ("FONTNAME", (0, 0), (-1, 0), bold_font),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#17233B")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#C8D0DC")),
                ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor("#F4F7FA")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    story.extend([summary_table, Spacer(1, 5 * mm), Paragraph("Зафиксированные события", heading_style)])

    if not violations:
        story.append(Paragraph("На обработанном видео нарушения не обнаружены.", body_style))
    else:
        event_rows = [["№", "Кадр", "Время", "ID", "Тип", "Увер."]]
        for index, item in enumerate(violations, start=1):
            event_rows.append(
                [
                    str(index),
                    str(item["frame_number"]),
                    f"{item['time_sec']:.2f} с",
                    str(item["track_id"]),
                    item["vehicle_class"],
                    f"{item['confidence']:.1%}",
                ]
            )
        event_table = Table(event_rows, repeatRows=1, colWidths=[11 * mm, 22 * mm, 24 * mm, 16 * mm, 52 * mm, 25 * mm])
        event_table.setStyle(
            TableStyle(
                [
                    ("FONTNAME", (0, 0), (-1, -1), regular_font),
                    ("FONTNAME", (0, 0), (-1, 0), bold_font),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D44242")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#C8D0DC")),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F4F7FA")]),
                    ("ALIGN", (0, 0), (3, -1), "CENTER"),
                    ("ALIGN", (5, 0), (5, -1), "CENTER"),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ]
            )
        )
        story.append(event_table)

        evidence_root = Path(evidence_dir)
        available_images = [
            (item, evidence_root / item["evidence_filename"])
            for item in violations[:20]
            if (evidence_root / item["evidence_filename"]).exists()
        ]
        if available_images:
            story.extend([PageBreak(), Paragraph("Кадры-подтверждения", heading_style)])
            for index, (item, image_path) in enumerate(available_images, start=1):
                story.append(
                    Paragraph(
                        f"Событие {index}: кадр {item['frame_number']}, "
                        f"время {item['time_sec']:.2f} с, ID {item['track_id']}",
                        body_style,
                    )
                )
                picture = Image(str(image_path))
                picture._restrictSize(170 * mm, 92 * mm)
                story.extend([picture, Spacer(1, 5 * mm)])

    document.build(story)
    return output


def export_json(path: str | Path, analysis: dict, violations: list[dict]) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as stream:
        json.dump({"analysis": analysis, "violations": violations}, stream, ensure_ascii=False, indent=2)
    return output
