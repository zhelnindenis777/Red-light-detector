"""Видеоаналитика: светофор, транспорт, трекинг и пересечение стоп-линии."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import cv2
import numpy as np
from ultralytics import YOLO


VEHICLE_CLASSES = {2: "автомобиль", 3: "мотоцикл", 5: "автобус", 7: "грузовик"}


@dataclass
class Track:
    track_id: int
    bbox: tuple[int, int, int, int]
    previous_bottom: int
    last_frame: int
    vehicle_class: str
    confidence: float
    frames_visible: int = 1
    violation_reported: bool = False


@dataclass
class CentroidTracker:
    max_distance: float = 110.0
    max_missing_frames: int = 30
    tracks: dict[int, Track] = field(default_factory=dict)
    next_id: int = 1

    @staticmethod
    def _center(bbox: tuple[int, int, int, int]) -> tuple[float, float]:
        x1, y1, x2, y2 = bbox
        return (x1 + x2) / 2, (y1 + y2) / 2

    def update(self, detections: list[dict], frame_number: int) -> list[Track]:
        candidates: list[tuple[float, int, int]] = []
        for detection_index, detection in enumerate(detections):
            dx, dy = self._center(detection["bbox"])
            for track_id, track in self.tracks.items():
                tx, ty = self._center(track.bbox)
                candidates.append((float(np.hypot(dx - tx, dy - ty)), detection_index, track_id))

        assigned_detections: set[int] = set()
        assigned_tracks: set[int] = set()
        active_tracks: list[Track] = []

        for distance, detection_index, track_id in sorted(candidates):
            if distance > self.max_distance:
                break
            if detection_index in assigned_detections or track_id in assigned_tracks:
                continue
            detection = detections[detection_index]
            track = self.tracks[track_id]
            track.previous_bottom = track.bbox[3]
            track.bbox = detection["bbox"]
            track.last_frame = frame_number
            track.vehicle_class = detection["vehicle_class"]
            track.confidence = detection["confidence"]
            track.frames_visible += 1
            assigned_detections.add(detection_index)
            assigned_tracks.add(track_id)
            active_tracks.append(track)

        for detection_index, detection in enumerate(detections):
            if detection_index in assigned_detections:
                continue
            bbox = detection["bbox"]
            track = Track(
                track_id=self.next_id,
                bbox=bbox,
                previous_bottom=bbox[3],
                last_frame=frame_number,
                vehicle_class=detection["vehicle_class"],
                confidence=detection["confidence"],
            )
            self.tracks[self.next_id] = track
            self.next_id += 1
            active_tracks.append(track)

        expired = [
            track_id
            for track_id, track in self.tracks.items()
            if frame_number - track.last_frame > self.max_missing_frames
        ]
        for track_id in expired:
            del self.tracks[track_id]

        return active_tracks


def detect_red_signal(
    frame: np.ndarray, roi: tuple[int, int, int, int], threshold: float
) -> tuple[bool, float]:
    x, y, width, height = roi
    frame_height, frame_width = frame.shape[:2]
    x1, y1 = max(0, x), max(0, y)
    x2, y2 = min(frame_width, x + width), min(frame_height, y + height)
    crop = frame[y1:y2, x1:x2]
    if crop.size == 0:
        return False, 0.0

    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    first = cv2.inRange(hsv, np.array([0, 80, 60]), np.array([10, 255, 255]))
    second = cv2.inRange(hsv, np.array([160, 80, 60]), np.array([180, 255, 255]))
    mask = cv2.bitwise_or(first, second)
    red_ratio = cv2.countNonZero(mask) / float(mask.size)
    return red_ratio >= threshold, red_ratio


def _extract_detections(result) -> list[dict]:
    if result.boxes is None or len(result.boxes) == 0:
        return []
    boxes = result.boxes.xyxy.cpu().numpy()
    confidences = result.boxes.conf.cpu().numpy()
    classes = result.boxes.cls.cpu().numpy().astype(int)
    detections = []
    for bbox, confidence, class_id in zip(boxes, confidences, classes):
        if class_id not in VEHICLE_CLASSES:
            continue
        detections.append(
            {
                "bbox": tuple(int(value) for value in bbox),
                "confidence": float(confidence),
                "vehicle_class": VEHICLE_CLASSES[class_id],
            }
        )
    return detections


def analyze_video(
    video_path: str | Path,
    evidence_dir: str | Path,
    stop_line_y: int,
    traffic_light_roi: tuple[int, int, int, int],
    red_threshold: float = 0.25,
    confidence: float = 0.50,
    model_path: str = "yolov8n.pt",
    progress_callback: Callable[[int], None] | None = None,
) -> dict:
    """Анализирует видео и возвращает сводку с событиями нарушений."""
    evidence_path = Path(evidence_dir)
    evidence_path.mkdir(parents=True, exist_ok=True)

    capture = cv2.VideoCapture(str(video_path))
    if not capture.isOpened():
        raise ValueError("Не удалось открыть загруженный видеофайл")

    fps = capture.get(cv2.CAP_PROP_FPS) or 30.0
    expected_frames = int(capture.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    model = YOLO(model_path)
    tracker = CentroidTracker()
    violations: list[dict] = []
    frame_number = 0

    try:
        while True:
            success, frame = capture.read()
            if not success:
                break
            frame_number += 1
            red_light, red_ratio = detect_red_signal(frame, traffic_light_roi, red_threshold)
            result = model.predict(frame, conf=confidence, iou=0.45, verbose=False)[0]
            active_tracks = tracker.update(_extract_detections(result), frame_number)

            for track in active_tracks:
                crossed_line = track.previous_bottom < stop_line_y <= track.bbox[3]
                if not (
                    red_light
                    and crossed_line
                    and track.frames_visible >= 3
                    and not track.violation_reported
                ):
                    continue

                track.violation_reported = True
                x1, y1, x2, y2 = track.bbox
                annotated = frame.copy()
                cv2.line(annotated, (0, stop_line_y), (annotated.shape[1], stop_line_y), (255, 80, 0), 3)
                cv2.rectangle(annotated, (x1, y1), (x2, y2), (0, 0, 255), 3)
                cv2.putText(
                    annotated,
                    f"VIOLATION ID {track.track_id}",
                    (x1, max(25, y1 - 12)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 0, 255),
                    2,
                )
                evidence_filename = f"violation_{frame_number:06d}_{track.track_id}.jpg"
                if not cv2.imwrite(str(evidence_path / evidence_filename), annotated):
                    raise OSError("Не удалось сохранить кадр нарушения")
                violations.append(
                    {
                        "frame_number": frame_number,
                        "time_sec": frame_number / fps,
                        "track_id": track.track_id,
                        "vehicle_class": track.vehicle_class,
                        "confidence": track.confidence,
                        "x1": x1,
                        "y1": y1,
                        "x2": x2,
                        "y2": y2,
                        "red_ratio": red_ratio,
                        "evidence_filename": evidence_filename,
                    }
                )

            if progress_callback and (frame_number == 1 or frame_number % 30 == 0):
                percent = max(1, min(99, int(frame_number / expected_frames * 100))) if expected_frames else 1
                progress_callback(percent)
    finally:
        capture.release()

    return {
        "total_frames": frame_number,
        "duration_sec": frame_number / fps if fps else 0,
        "fps": fps,
        "violations": violations,
    }
