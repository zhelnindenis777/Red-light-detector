const form = document.querySelector('#analysis-form');
const fileInput = document.querySelector('#video');
const fileLabel = document.querySelector('#file-label');
const dropzone = document.querySelector('#dropzone');
const message = document.querySelector('#form-message');
const historyBody = document.querySelector('#history-body');
const refreshButton = document.querySelector('#refresh-button');
const dialog = document.querySelector('#details-dialog');
const dialogTitle = document.querySelector('#dialog-title');
const dialogContent = document.querySelector('#dialog-content');

const statusLabels = {
  queued: 'В очереди', processing: 'Выполняется', completed: 'Завершён', failed: 'Ошибка'
};

function escapeHtml(value) {
  const element = document.createElement('div');
  element.textContent = String(value ?? '');
  return element.innerHTML;
}

function formatDate(value) {
  if (!value) return '—';
  return new Intl.DateTimeFormat('ru-RU', {dateStyle: 'short', timeStyle: 'short'}).format(new Date(value));
}

function setSelectedFile(file) {
  if (file) fileLabel.textContent = `${file.name} · ${(file.size / 1024 / 1024).toFixed(1)} МБ`;
}

fileInput.addEventListener('change', () => setSelectedFile(fileInput.files[0]));
['dragenter', 'dragover'].forEach((eventName) => dropzone.addEventListener(eventName, (event) => {
  event.preventDefault();
  dropzone.classList.add('is-dragging');
}));
['dragleave', 'drop'].forEach((eventName) => dropzone.addEventListener(eventName, (event) => {
  event.preventDefault();
  dropzone.classList.remove('is-dragging');
}));
dropzone.addEventListener('drop', (event) => {
  if (!event.dataTransfer.files.length) return;
  const transfer = new DataTransfer();
  transfer.items.add(event.dataTransfer.files[0]);
  fileInput.files = transfer.files;
  setSelectedFile(fileInput.files[0]);
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  message.className = 'message';
  message.textContent = 'Загрузка файла и создание задания…';
  try {
    const response = await fetch('/api/analyses', {method: 'POST', body: new FormData(form)});
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Не удалось запустить анализ');
    message.className = 'message success';
    message.textContent = 'Анализ запущен. Прогресс отображается в истории.';
    await loadHistory();
    document.querySelector('.history-section').scrollIntoView({behavior: 'smooth'});
  } catch (error) {
    message.className = 'message error';
    message.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

function actionLinks(item) {
  const detail = `<button type="button" data-details="${item.id}">Детали</button>`;
  if (item.status !== 'completed') return detail;
  return `${detail}<a href="${item.excel_url}">Excel</a><a href="${item.pdf_url}">PDF</a><a href="${item.json_url}">JSON</a>`;
}

async function loadHistory() {
  try {
    const response = await fetch('/api/analyses');
    const items = await response.json();
    if (!items.length) {
      historyBody.innerHTML = '<tr><td colspan="6" class="empty-state">Пока нет ни одного анализа.</td></tr>';
      return;
    }
    historyBody.innerHTML = items.map((item) => `
      <tr>
        <td class="file-cell"><strong>${escapeHtml(item.original_filename)}</strong><small>${formatDate(item.created_at)}</small></td>
        <td><span class="badge ${item.status}">${statusLabels[item.status] || item.status}</span>${item.error_message ? `<small title="${escapeHtml(item.error_message)}"> Ошибка обработки</small>` : ''}</td>
        <td><div class="progress-track" title="${item.progress}%"><i style="width:${item.progress}%"></i></div></td>
        <td>${item.total_frames || '—'}</td>
        <td><strong>${item.violations_count}</strong></td>
        <td><div class="action-links">${actionLinks(item)}</div></td>
      </tr>`).join('');
    historyBody.querySelectorAll('[data-details]').forEach((button) => {
      button.addEventListener('click', () => showDetails(button.dataset.details));
    });
  } catch (_error) {
    historyBody.innerHTML = '<tr><td colspan="6" class="empty-state">Не удалось загрузить историю.</td></tr>';
  }
}

async function showDetails(analysisId) {
  const response = await fetch(`/api/analyses/${analysisId}`);
  if (!response.ok) return;
  const item = await response.json();
  dialogTitle.textContent = item.original_filename;
  const evidence = item.violations.length
    ? `<div class="evidence-grid">${item.violations.map((event, index) => `
        <article class="evidence-card">
          <img src="${event.evidence_url}" alt="Кадр нарушения ${index + 1}" loading="lazy">
          <div><strong>Событие ${index + 1} · ID ${event.track_id}</strong><span>${event.time_sec.toFixed(2)} с</span></div>
        </article>`).join('')}</div>`
    : `<p class="empty-state">${item.status === 'completed' ? 'Нарушения не обнаружены.' : 'Кадры появятся после завершения обработки.'}</p>`;
  dialogContent.innerHTML = `
    <div class="result-stats">
      <div><span>Статус</span><strong>${statusLabels[item.status] || item.status}</strong></div>
      <div><span>Кадры</span><strong>${item.total_frames || '—'}</strong></div>
      <div><span>Длительность</span><strong>${item.duration_sec ? item.duration_sec.toFixed(1) + ' с' : '—'}</strong></div>
      <div><span>Нарушения</span><strong>${item.violations_count}</strong></div>
    </div>
    ${item.error_message ? `<p class="message error">${escapeHtml(item.error_message)}</p>` : ''}
    ${evidence}`;
  dialog.showModal();
}

document.querySelector('#dialog-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
refreshButton.addEventListener('click', loadHistory);

loadHistory();
setInterval(() => {
  if (document.visibilityState === 'visible') loadHistory();
}, 5000);
