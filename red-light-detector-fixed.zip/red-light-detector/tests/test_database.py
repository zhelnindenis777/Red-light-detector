from pathlib import Path

import database


def test_analysis_and_violations_are_saved(tmp_path: Path):
    database_path = tmp_path / "history.sqlite3"
    database.init_db(database_path)
    analysis_id = database.create_analysis(
        database_path,
        {
            "original_filename": "crossroad.mp4",
            "stored_filename": "stored.mp4",
            "stop_line_y": 335,
            "traffic_light_x": 1165,
            "traffic_light_y": 50,
            "traffic_light_w": 65,
            "traffic_light_h": 80,
            "red_threshold": 0.25,
            "confidence": 0.5,
        },
    )
    database.update_analysis(database_path, analysis_id, status="completed", progress=100)
    database.add_violations(
        database_path,
        analysis_id,
        [
            {
                "frame_number": 42,
                "time_sec": 1.4,
                "track_id": 3,
                "vehicle_class": "автомобиль",
                "confidence": 0.91,
                "x1": 10,
                "y1": 20,
                "x2": 110,
                "y2": 90,
                "red_ratio": 0.37,
                "evidence_filename": "proof.jpg",
            }
        ],
    )

    saved_analysis = database.get_analysis(database_path, analysis_id)
    saved_events = database.get_violations(database_path, analysis_id)

    assert saved_analysis["status"] == "completed"
    assert saved_analysis["progress"] == 100
    assert saved_events[0]["frame_number"] == 42
    assert saved_events[0]["vehicle_class"] == "автомобиль"
