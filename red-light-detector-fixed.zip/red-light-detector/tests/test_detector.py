import numpy as np

from detector import CentroidTracker, detect_red_signal


def test_red_signal_is_detected_inside_roi():
    frame = np.zeros((100, 100, 3), dtype=np.uint8)
    frame[10:40, 10:40] = (0, 0, 255)
    is_red, ratio = detect_red_signal(frame, (10, 10, 30, 30), 0.25)
    assert is_red is True
    assert ratio > 0.95


def test_tracker_keeps_id_for_nearby_detection():
    tracker = CentroidTracker(max_distance=50)
    first = tracker.update(
        [{"bbox": (10, 10, 30, 30), "vehicle_class": "автомобиль", "confidence": 0.9}],
        frame_number=1,
    )[0]
    second = tracker.update(
        [{"bbox": (12, 15, 32, 35), "vehicle_class": "автомобиль", "confidence": 0.91}],
        frame_number=2,
    )[0]
    assert first.track_id == second.track_id
    assert second.previous_bottom == 30
    assert second.bbox[3] == 35
