import io
from pathlib import Path

import app as app_module


def test_web_flow_and_exports(tmp_path: Path, monkeypatch):
    def fake_analyze_video(**_kwargs):
        return {
            "total_frames": 300,
            "duration_sec": 10.0,
            "fps": 30.0,
            "violations": [],
        }

    monkeypatch.setattr(app_module, "analyze_video", fake_analyze_video)
    application = app_module.create_app(
        {
            "TESTING": True,
            "SYNC_ANALYSIS": True,
            "DATABASE": str(tmp_path / "test.sqlite3"),
            "UPLOAD_FOLDER": str(tmp_path / "uploads"),
            "EVIDENCE_FOLDER": str(tmp_path / "evidence"),
            "EXPORT_FOLDER": str(tmp_path / "exports"),
        }
    )
    client = application.test_client()

    assert client.get("/").status_code == 200
    assert client.get("/api/health").json == {"status": "ok"}

    response = client.post(
        "/api/analyses",
        data={
            "video": (io.BytesIO(b"test-video"), "crossroad.mp4"),
            "stop_line_y": "335",
            "traffic_light_x": "1165",
            "traffic_light_y": "50",
            "traffic_light_w": "65",
            "traffic_light_h": "80",
            "red_threshold": "0.25",
            "confidence": "0.50",
        },
        content_type="multipart/form-data",
    )
    assert response.status_code == 201
    analysis = response.get_json()
    assert analysis["status"] == "completed"
    analysis_id = analysis["id"]

    details = client.get(f"/api/analyses/{analysis_id}")
    assert details.status_code == 200
    assert details.get_json()["total_frames"] == 300

    excel = client.get(f"/api/analyses/{analysis_id}/export.xlsx")
    pdf = client.get(f"/api/analyses/{analysis_id}/export.pdf")
    json_export = client.get(f"/api/analyses/{analysis_id}/export.json")
    assert excel.status_code == 200
    assert excel.data.startswith(b"PK")
    assert pdf.status_code == 200
    assert pdf.data.startswith(b"%PDF")
    assert json_export.status_code == 200
    assert b'"violations": []' in json_export.data


def test_invalid_extension_is_rejected(tmp_path: Path):
    application = app_module.create_app(
        {
            "TESTING": True,
            "DATABASE": str(tmp_path / "test.sqlite3"),
            "UPLOAD_FOLDER": str(tmp_path / "uploads"),
            "EVIDENCE_FOLDER": str(tmp_path / "evidence"),
            "EXPORT_FOLDER": str(tmp_path / "exports"),
        }
    )
    client = application.test_client()
    response = client.post(
        "/api/analyses",
        data={"video": (io.BytesIO(b"not-video"), "notes.txt")},
        content_type="multipart/form-data",
    )
    assert response.status_code == 400
