"""Работа с локальной базой данных SQLite."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4


ANALYSIS_FIELDS = {
    "status",
    "started_at",
    "finished_at",
    "progress",
    "total_frames",
    "duration_sec",
    "fps",
    "violations_count",
    "error_message",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect(database_path: str | Path) -> sqlite3.Connection:
    connection = sqlite3.connect(str(database_path), timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA journal_mode = WAL")
    return connection


def init_db(database_path: str | Path) -> None:
    path = Path(database_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with connect(path) as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS analyses (
                id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                started_at TEXT,
                finished_at TEXT,
                status TEXT NOT NULL CHECK(status IN ('queued', 'processing', 'completed', 'failed')),
                progress INTEGER NOT NULL DEFAULT 0,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                stop_line_y INTEGER NOT NULL,
                traffic_light_x INTEGER NOT NULL,
                traffic_light_y INTEGER NOT NULL,
                traffic_light_w INTEGER NOT NULL,
                traffic_light_h INTEGER NOT NULL,
                red_threshold REAL NOT NULL,
                confidence REAL NOT NULL,
                total_frames INTEGER NOT NULL DEFAULT 0,
                duration_sec REAL NOT NULL DEFAULT 0,
                fps REAL NOT NULL DEFAULT 0,
                violations_count INTEGER NOT NULL DEFAULT 0,
                error_message TEXT
            );

            CREATE TABLE IF NOT EXISTS violations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                analysis_id TEXT NOT NULL,
                frame_number INTEGER NOT NULL,
                time_sec REAL NOT NULL,
                track_id INTEGER NOT NULL,
                vehicle_class TEXT NOT NULL,
                confidence REAL NOT NULL,
                x1 INTEGER NOT NULL,
                y1 INTEGER NOT NULL,
                x2 INTEGER NOT NULL,
                y2 INTEGER NOT NULL,
                red_ratio REAL NOT NULL,
                evidence_filename TEXT NOT NULL,
                FOREIGN KEY (analysis_id) REFERENCES analyses(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_violations_analysis
                ON violations(analysis_id);
            """
        )


def create_analysis(database_path: str | Path, values: dict[str, Any]) -> str:
    analysis_id = uuid4().hex
    with connect(database_path) as connection:
        connection.execute(
            """
            INSERT INTO analyses (
                id, created_at, status, original_filename, stored_filename,
                stop_line_y, traffic_light_x, traffic_light_y,
                traffic_light_w, traffic_light_h, red_threshold, confidence
            ) VALUES (?, ?, 'queued', ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                analysis_id,
                utc_now(),
                values["original_filename"],
                values["stored_filename"],
                values["stop_line_y"],
                values["traffic_light_x"],
                values["traffic_light_y"],
                values["traffic_light_w"],
                values["traffic_light_h"],
                values["red_threshold"],
                values["confidence"],
            ),
        )
    return analysis_id


def update_analysis(database_path: str | Path, analysis_id: str, **values: Any) -> None:
    invalid = set(values) - ANALYSIS_FIELDS
    if invalid:
        raise ValueError(f"Недопустимые поля обновления: {sorted(invalid)}")
    if not values:
        return
    assignments = ", ".join(f"{field} = ?" for field in values)
    with connect(database_path) as connection:
        connection.execute(
            f"UPDATE analyses SET {assignments} WHERE id = ?",
            (*values.values(), analysis_id),
        )


def add_violations(
    database_path: str | Path, analysis_id: str, violations: list[dict[str, Any]]
) -> None:
    if not violations:
        return
    rows = [
        (
            analysis_id,
            item["frame_number"],
            item["time_sec"],
            item["track_id"],
            item["vehicle_class"],
            item["confidence"],
            item["x1"],
            item["y1"],
            item["x2"],
            item["y2"],
            item["red_ratio"],
            item["evidence_filename"],
        )
        for item in violations
    ]
    with connect(database_path) as connection:
        connection.executemany(
            """
            INSERT INTO violations (
                analysis_id, frame_number, time_sec, track_id, vehicle_class,
                confidence, x1, y1, x2, y2, red_ratio, evidence_filename
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )


def get_analysis(database_path: str | Path, analysis_id: str) -> dict[str, Any] | None:
    with connect(database_path) as connection:
        row = connection.execute(
            "SELECT * FROM analyses WHERE id = ?", (analysis_id,)
        ).fetchone()
    return dict(row) if row else None


def list_analyses(database_path: str | Path, limit: int = 100) -> list[dict[str, Any]]:
    with connect(database_path) as connection:
        rows = connection.execute(
            "SELECT * FROM analyses ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
    return [dict(row) for row in rows]


def get_violations(database_path: str | Path, analysis_id: str) -> list[dict[str, Any]]:
    with connect(database_path) as connection:
        rows = connection.execute(
            "SELECT * FROM violations WHERE analysis_id = ? ORDER BY frame_number",
            (analysis_id,),
        ).fetchall()
    return [dict(row) for row in rows]
