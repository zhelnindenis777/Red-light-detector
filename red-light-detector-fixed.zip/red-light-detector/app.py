"""Flask-приложение для детекции проезда на красный сигнал светофора."""

from __future__ import annotations

import atexit
import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from uuid import uuid4

from flask import Flask, abort, jsonify, render_template, request, send_file, send_from_directory, url_for
from werkzeug.utils import secure_filename

import database
from detector import analyze_video
from exporters import export_excel, export_json, export_pdf


ALLOWED_VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm"}


def _integer_form_field(name: str, minimum: int = 0) -> int:
    raw_value = request.form.get(name, "")
    try:
        value = int(raw_value)
    except ValueError as error:
        raise ValueError(f"Поле {name} должно быть целым числом") from error
    if value < minimum:
        raise ValueError(f"Поле {name} должно быть не меньше {minimum}")
    return value


def _float_form_field(name: str, default: float, minimum: float, maximum: float) -> float:
    raw_value = request.form.get(name, str(default))
    try:
        value = float(raw_value)
    except ValueError as error:
        raise ValueError(f"Поле {name} должно быть числом") from error
    if not minimum <= value <= maximum:
        raise ValueError(f"Поле {name} должно быть от {minimum} до {maximum}")
    return value


def _serialize_analysis(item: dict) -> dict:
    result = dict(item)
    result["details_url"] = url_for("analysis_details", analysis_id=item["id"])
    if item["status"] == "completed":
        result["excel_url"] = url_for("download_export", analysis_id=item["id"], export_format="xlsx")
        result["pdf_url"] = url_for("download_export", analysis_id=item["id"], export_format="pdf")
        result["json_url"] = url_for("download_export", analysis_id=item["id"], export_format="json")
    return result


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        MAX_CONTENT_LENGTH=500 * 1024 * 1024,
        DATABASE=str(Path(app.instance_path) / "red_light_detector.sqlite3"),
        UPLOAD_FOLDER=str(Path(app.instance_path) / "uploads"),
        EVIDENCE_FOLDER=str(Path(app.instance_path) / "evidence"),
        EXPORT_FOLDER=str(Path(app.instance_path) / "exports"),
        YOLO_MODEL=os.environ.get("YOLO_MODEL", "yolov8n.pt"),
        SYNC_ANALYSIS=False,
    )
    if test_config:
        app.config.update(test_config)

    for folder_key in ("UPLOAD_FOLDER", "EVIDENCE_FOLDER", "EXPORT_FOLDER"):
        Path(app.config[folder_key]).mkdir(parents=True, exist_ok=True)
    database.init_db(app.config["DATABASE"])

    executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="video-analysis")
    app.extensions["analysis_executor"] = executor
    atexit.register(executor.shutdown, wait=False, cancel_futures=True)

    def run_analysis(analysis_id: str) -> None:
        with app.app_context():
            item = database.get_analysis(app.config["DATABASE"], analysis_id)
            if not item:
                return
            database.update_analysis(
                app.config["DATABASE"],
                analysis_id,
                status="processing",
                started_at=database.utc_now(),
                progress=1,
                error_message=None,
            )
            try:
                result = analyze_video(
                    video_path=Path(app.config["UPLOAD_FOLDER"]) / item["stored_filename"],
                    evidence_dir=Path(app.config["EVIDENCE_FOLDER"]) / analysis_id,
                    stop_line_y=item["stop_line_y"],
                    traffic_light_roi=(
                        item["traffic_light_x"],
                        item["traffic_light_y"],
                        item["traffic_light_w"],
                        item["traffic_light_h"],
                    ),
                    red_threshold=item["red_threshold"],
                    confidence=item["confidence"],
                    model_path=app.config["YOLO_MODEL"],
                    progress_callback=lambda progress: database.update_analysis(
                        app.config["DATABASE"], analysis_id, progress=progress
                    ),
                )
                database.add_violations(app.config["DATABASE"], analysis_id, result["violations"])
                database.update_analysis(
                    app.config["DATABASE"],
                    analysis_id,
                    status="completed",
                    finished_at=database.utc_now(),
                    progress=100,
                    total_frames=result["total_frames"],
                    duration_sec=result["duration_sec"],
                    fps=result["fps"],
                    violations_count=len(result["violations"]),
                )
            except Exception as error:  # Ошибка сохраняется в истории и показывается пользователю.
                app.logger.exception("Ошибка анализа %s", analysis_id)
                database.update_analysis(
                    app.config["DATABASE"],
                    analysis_id,
                    status="failed",
                    finished_at=database.utc_now(),
                    error_message=str(error),
                )

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok"})

    @app.get("/api/analyses")
    def analyses_list():
        items = database.list_analyses(app.config["DATABASE"])
        return jsonify([_serialize_analysis(item) for item in items])

    @app.post("/api/analyses")
    def create_analysis_route():
        try:
            uploaded_file = request.files.get("video")
            if not uploaded_file or not uploaded_file.filename:
                raise ValueError("Выберите видеофайл")
            extension = Path(uploaded_file.filename).suffix.lower()
            if extension not in ALLOWED_VIDEO_EXTENSIONS:
                raise ValueError("Поддерживаются MP4, MOV, AVI, MKV и WEBM")

            original_filename = secure_filename(uploaded_file.filename) or f"video{extension}"
            stored_filename = f"{uuid4().hex}{extension}"
            target = Path(app.config["UPLOAD_FOLDER"]) / stored_filename
            uploaded_file.save(target)
            values = {
                "original_filename": original_filename,
                "stored_filename": stored_filename,
                "stop_line_y": _integer_form_field("stop_line_y"),
                "traffic_light_x": _integer_form_field("traffic_light_x"),
                "traffic_light_y": _integer_form_field("traffic_light_y"),
                "traffic_light_w": _integer_form_field("traffic_light_w", 1),
                "traffic_light_h": _integer_form_field("traffic_light_h", 1),
                "red_threshold": _float_form_field("red_threshold", 0.25, 0.01, 1.0),
                "confidence": _float_form_field("confidence", 0.50, 0.01, 1.0),
            }
            analysis_id = database.create_analysis(app.config["DATABASE"], values)
        except ValueError as error:
            if "target" in locals():
                target.unlink(missing_ok=True)
            return jsonify({"error": str(error)}), 400

        if app.config["SYNC_ANALYSIS"]:
            run_analysis(analysis_id)
        else:
            executor.submit(run_analysis, analysis_id)
        item = database.get_analysis(app.config["DATABASE"], analysis_id)
        return jsonify(_serialize_analysis(item)), 201

    @app.get("/api/analyses/<analysis_id>")
    def analysis_details(analysis_id: str):
        item = database.get_analysis(app.config["DATABASE"], analysis_id)
        if not item:
            abort(404)
        result = _serialize_analysis(item)
        violations = database.get_violations(app.config["DATABASE"], analysis_id)
        for violation in violations:
            violation["evidence_url"] = url_for(
                "evidence_file",
                analysis_id=analysis_id,
                filename=violation["evidence_filename"],
            )
        result["violations"] = violations
        return jsonify(result)

    @app.get("/evidence/<analysis_id>/<path:filename>")
    def evidence_file(analysis_id: str, filename: str):
        if not database.get_analysis(app.config["DATABASE"], analysis_id):
            abort(404)
        return send_from_directory(Path(app.config["EVIDENCE_FOLDER"]) / analysis_id, filename)

    @app.get("/api/analyses/<analysis_id>/export.<export_format>")
    def download_export(analysis_id: str, export_format: str):
        item = database.get_analysis(app.config["DATABASE"], analysis_id)
        if not item:
            abort(404)
        if item["status"] != "completed":
            return jsonify({"error": "Экспорт доступен после завершения анализа"}), 409
        violations = database.get_violations(app.config["DATABASE"], analysis_id)
        export_path = Path(app.config["EXPORT_FOLDER"]) / f"analysis_{analysis_id}.{export_format}"
        if export_format == "xlsx":
            export_excel(export_path, item, violations)
            mimetype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        elif export_format == "pdf":
            export_pdf(export_path, item, violations, Path(app.config["EVIDENCE_FOLDER"]) / analysis_id)
            mimetype = "application/pdf"
        elif export_format == "json":
            export_json(export_path, item, violations)
            mimetype = "application/json"
        else:
            abort(404)
        return send_file(
            export_path,
            as_attachment=True,
            download_name=f"red_light_analysis_{analysis_id[:8]}.{export_format}",
            mimetype=mimetype,
        )

    @app.errorhandler(404)
    def not_found(_error):
        if request.path.startswith("/api/"):
            return jsonify({"error": "Ресурс не найден"}), 404
        return render_template("index.html"), 404

    @app.errorhandler(413)
    def file_too_large(_error):
        return jsonify({"error": "Файл превышает допустимый размер 500 МБ"}), 413

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
